CastDuo Plus / Cinematic
Serve locally and open index.html. 390x844. Three room photos, 2s per scene, 6s loop. Reduced Motion keeps sunset static. Purchase is simulated; real StoreKit data and policy URLs are required.
