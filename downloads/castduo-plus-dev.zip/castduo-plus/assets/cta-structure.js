/* CTA hierarchy from SmartHue 539:32897. Preserve each paywall's visual skin. */
(()=>{
 const previous=render;
 render=function(o){
  const html=previous(o.state==='loading'?{...o,state:'ready',eligibility:'unknown'}:o),{trial,p}=context(o);
  const template=document.createElement('template');template.innerHTML=html;
  const area=template.content.querySelector('.purchase-area');
  if(!area)return html;
  const button=area.querySelector('.primary'),legal=area.querySelector('.disclosure'),links=area.querySelector('.utility');
  if(!button||!links)return html;
  // Shared offer wording; each layout keeps its existing type and geometry.
  const offerCard=area.querySelector('.cinema-plan,.hy-offer,.atlas-plan,.in-offer');
  if(offerCard){
   const label=offerCard.querySelector(':scope > div'),rate=offerCard.querySelector(':scope > b');
   if(label&&rate){
    label.innerHTML='<strong>Weekly</strong>';
    if(trial){rate.classList.add('offer-trial');rate.innerHTML=`3-day free trial<small>then ${esc(p.price)}/week</small>`;}
   }
  }
  const group=document.createElement('div');group.className='cta-structure';
  const main=document.createElement('div');main.className='cta-main';
  if(legal){
   if(legal.textContent.trim()&&!o.locale&&p.type==='subscription'){
    legal.innerHTML=trial?`Try free for ${esc(p.trialDuration)}, then ${esc(p.price)}/${esc(p.period)}.<br>Auto-renews. Cancel anytime.`:`${esc(p.price)}/${esc(p.period)}.<br>Auto-renews. Cancel anytime.`;
   }
   main.append(legal);
  }
  const aura=button.closest('.cta-aura');main.append(aura||button);group.append(main);
  if(trial&&!['loading','load-error','empty'].includes(o.state)){
   const badge=document.createElement('div');badge.className='cta-payment';
   badge.innerHTML='<span class="cta-payment-icon"><img src="assets/cta-payment-check.svg" alt=""></span><span>No payment due now</span>';
   group.append(badge);
  }
  area.classList.add('cta-updated');area.append(group);
  const footer=document.createElement('div');footer.className='utility cta-footer';
  for(const action of ['privacy','terms','restore']){
   const link=links.querySelector(`[data-action="${action}"]`);
   if(link){if(!o.locale)link.textContent=action==='privacy'?'Privacy Policy':action==='terms'?'Terms of Service':o.state==='restoring'?'Restoring…':'Restore';footer.append(link);}
  }
  links.remove();area.append(footer);
  if(['loading','purchasing'].includes(o.state)){
   area.classList.add('billing-busy');area.querySelectorAll('.status').forEach(el=>el.remove());
   area.querySelector('.cta-payment')?.remove();
   if(o.state==='loading'&&o.eligibility==='eligible'){const space=document.createElement('div');space.className='billing-payment-space';space.setAttribute('aria-hidden','true');group.append(space);}
   if(o.state==='loading'){const row=template.content.querySelector('.gallery-timeline li:last-child');if(row){row.classList.add('billing-timeline-placeholder');row.setAttribute('aria-hidden','true');}}
   button.disabled=true;button.setAttribute('aria-busy','true');
   const loading=o.state==='loading';
   button.setAttribute('aria-label',loading?'Loading plans…':'Opening App Store…');
   button.innerHTML='<span class="billing-spinner" aria-hidden="true"></span>'+(loading?'':'<span>Opening App Store…</span>');
   if(loading){
    const card=area.querySelector('.go-plan,.cinema-plan,.hy-offer,.atlas-plan,.in-offer');
    if(card){card.classList.add('billing-skeleton-card');card.setAttribute('role','status');card.setAttribute('aria-label','Loading plans…');card.innerHTML='<div class="billing-skeleton-label" aria-hidden="true"><span></span><span></span></div><span class="billing-skeleton-price" aria-hidden="true"></span>';}
    if(legal){legal.classList.add('billing-skeleton-legal');legal.setAttribute('aria-hidden','true');legal.innerHTML='<span></span>';}
   }
  }
  return template.innerHTML;
 };
 board();
})();
