CastDuo PRO / iOS interactive concept
Serve this folder with a local HTTP server and open index.html.
Native frame 390x844; status bar included.
Motion uses CSS, not Lottie. Reduced Motion renders a static badge.
Purchase and restore are simulations. Real product IDs, storefront pricing, StoreKit eligibility and policy URLs are still required.
